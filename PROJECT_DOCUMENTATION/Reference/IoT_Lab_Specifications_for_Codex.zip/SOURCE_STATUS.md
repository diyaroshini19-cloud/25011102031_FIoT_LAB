# Lab specification bundle status

This bundle contains the readable original lab evaluation PDFs supplied in ChatGPT.

Included:
- CAT2, CAT3, CAT5, CAT6, CAT7, CAT8, CAT11, CAT12, CAT13.

Unavailable or invalid uploads:
- CAT4: uploaded PDF was only 110 bytes and could not be read.
- CAT9: uploaded PDF was only 110 bytes and could not be read.
- CAT10: uploaded PDF was only 110 bytes and could not be read.
- CAT14: no PDF was supplied in this upload batch.

Important:
- Some PDFs are scanned/image-based. Inspect all pages, including diagrams and screenshots.
- Do not infer missing experiment requirements from adjacent CATs.
- Ask for the missing CAT sheets before implementing tasks whose requirements depend on them.
- Use the original PDFs as the source of truth.
